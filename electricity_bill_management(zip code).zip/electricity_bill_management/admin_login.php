<?php
session_start();
include_once("db.php");

$error = "";

if(isset($_POST['login']))
{
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if($username == "admin" && $password == "admin123")
    {
        $_SESSION['admin'] = "admin";
        header("Location: dashboard.php");
        exit();
    }
    else
    {
        $error = "Invalid Username or Password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>

<style>
body{
    margin:0;
    font-family:Arial;
    background: linear-gradient(135deg,#0f172a,#1e3a8a);
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

.login-box{
    width:380px;
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0px 15px 30px rgba(0,0,0,0.4);
}

h2{
    text-align:center;
    color:#1e3a8a;
    margin-bottom:20px;
}

.input-box{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:1px solid #ddd;
    border-radius:8px;
    outline:none;
}

.input-box:focus{
    border-color:#1e3a8a;
}

.btn{
    width:100%;
    padding:12px;
    background:#1e3a8a;
    color:white;
    border:none;
    border-radius:8px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

.btn:hover{
    background:#0f172a;
}

.error{
    color:red;
    text-align:center;
    margin-bottom:10px;
    font-size:14px;
}

.footer-text{
    text-align:center;
    margin-top:15px;
    font-size:12px;
    color:gray;
}
</style>

</head>

<body>

<div class="login-box">

<h2>Admin Login</h2>

<?php if($error != "") { ?>
    <div class="error"><?php echo $error; ?></div>
<?php } ?>

<form method="POST">

<input class="input-box" type="text" name="username" placeholder="Enter Username" required>

<input class="input-box" type="password" name="password" placeholder="Enter Password" required>

<button class="btn" type="submit" name="login">LOGIN</button>

</form>

<div class="footer-text">
Electricity Bill Management System
</div>

</div>

</body>
</html>