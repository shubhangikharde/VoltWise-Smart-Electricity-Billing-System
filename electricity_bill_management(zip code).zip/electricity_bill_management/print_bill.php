<?php
include "db.php";

if(!isset($_GET['id']))
{
    header("Location: bill_history.php");
    exit();
}

$id = $_GET['id'];

$sql = "SELECT bills.*, customers.customer_name, customers.mobile,
customers.address
FROM bills
INNER JOIN customers
ON bills.customer_id = customers.customer_id
WHERE bills.bill_id='$id'";

$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>

<title>Electricity Bill</title>

<style>

body{
font-family:Arial;
background:#f4f4f4;
}

.bill{
width:700px;
margin:30px auto;
background:white;
padding:30px;
border:2px solid #333;
}

h1,h2{
text-align:center;
}

table{
width:100%;
border-collapse:collapse;
margin-top:20px;
}

table th,table td{
border:1px solid #000;
padding:10px;
text-align:left;
}

button{
margin-top:20px;
padding:10px 20px;
background:#1e3a8a;
color:white;
border:none;
cursor:pointer;
}

</style>

</head>

<body>

<div class="bill">

<h1>Electricity Bill</h1>

<h2>Electricity Bill Management System</h2>

<table>

<tr>
<th>Bill ID</th>
<td><?php echo $row['bill_id']; ?></td>
</tr>

<tr>
<th>Customer Name</th>
<td><?php echo $row['customer_name']; ?></td>
</tr>

<tr>
<th>Mobile</th>
<td><?php echo $row['mobile']; ?></td>
</tr>

<tr>
<th>Address</th>
<td><?php echo $row['address']; ?></td>
</tr>

<tr>
<th>Meter Number</th>
<td><?php echo $row['meter_number']; ?></td>
</tr>

<tr>
<th>Billing Month</th>
<td><?php echo $row['billing_month']; ?></td>
</tr>

<tr>
<th>Previous Reading</th>
<td><?php echo $row['previous_reading']; ?></td>
</tr>

<tr>
<th>Current Reading</th>
<td><?php echo $row['current_reading']; ?></td>
</tr>

<tr>
<th>Units Consumed</th>
<td><?php echo $row['units']; ?></td>
</tr>

<tr>
<th>Rate Per Unit</th>
<td>₹ <?php echo $row['rate']; ?></td>
</tr>

<tr>
<th>Total Amount</th>
<td><b>₹ <?php echo $row['total_amount']; ?></b></td>
</tr>

<tr>
<th>Bill Date</th>
<td><?php echo $row['bill_date']; ?></td>
</tr>

<tr>
<th>Payment Status</th>
<td><?php echo $row['payment_status']; ?></td>
</tr>

</table>

<center>

<button onclick="window.print()">
Print Bill
</button>

</center>

</div>

</body>
</html>