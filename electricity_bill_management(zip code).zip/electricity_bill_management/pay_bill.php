<?php
session_start();

if(!isset($_SESSION['customer_id']))
{
    header("Location:user_login.php");
    exit();
}

include "db.php";

if(isset($_GET['id']))
{
    $bill_id = $_GET['id'];
    $customer_id = $_SESSION['customer_id'];

    // Check whether the bill belongs to the logged-in customer
    $check = mysqli_query($conn,
    "SELECT * FROM bills
     WHERE bill_id='$bill_id'
     AND customer_id='$customer_id'");

    if(mysqli_num_rows($check)==1)
    {
        // Update payment status
        $update = mysqli_query($conn,
        "UPDATE bills
         SET payment_status='Paid'
         WHERE bill_id='$bill_id'");

        if($update)
        {
            echo "<script>
                    alert('Payment Successful');
                    window.location='my_bills.php';
                  </script>";
        }
        else
        {
            echo "<script>
                    alert('Payment Failed');
                    window.location='my_bills.php';
                  </script>";
        }
    }
    else
    {
        echo "<script>
                alert('Invalid Bill');
                window.location='my_bills.php';
              </script>";
    }
}
else
{
    header("Location:my_bills.php");
}
?>