<!DOCTYPE html>
<html>
<head>
<title>Electricity Bill Management System</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>

<h2>Electricity Bill Management System</h2>

<nav>
<a href="index.php">Dashboard</a>
<a href="add_customer.php">Add Customer</a>
<a href="view_customers.php">Customers</a>
<a href="generate_bill.php">Generate Bill</a>
<a href="bill_history.php">Bill History</a>
</nav>

</header>

<div class="container">