<?php
include "db.php";

if(isset($_POST['register']))
{
    $name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if($password != $confirm_password)
    {
        echo "<script>alert('Password does not match');</script>";
    }
    else
    {
        // Check if user already exists
        $check = mysqli_query($conn,
        "SELECT * FROM customers WHERE mobile='$mobile'");

        if(mysqli_num_rows($check) > 0)
        {
            echo "<script>alert('User already exists with this mobile number');</script>";
        }
        else
        {
            $sql = "INSERT INTO customers
            (customer_name, mobile, email, address, password)
            VALUES
            ('$name', '$mobile', '$email', '$address', '$password')";

            if(mysqli_query($conn, $sql))
            {
                echo "<script>
                alert('Registration Successful');
                window.location='user_login.php';
                </script>";
            }
            else
            {
                echo "<script>alert('Error in Registration');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

<h2 style="text-align:center;">Customer Registration</h2>

<form method="POST">

<label>Full Name</label>
<input type="text" name="customer_name" required>

<label>Mobile Number</label>
<input type="text" name="mobile" required>

<label>Email</label>
<input type="email" name="email">

<label>Address</label>
<textarea name="address" required></textarea>

<label>Password</label>
<input type="password" name="password" required>

<label>Confirm Password</label>
<input type="password" name="confirm_password" required>

<button type="submit" name="register">
Register
</button>

</form>

<br>

<p style="text-align:center;">
Already have account?
<a href="user_login.php">Login Here</a>
</p>

</div>

</body>
</html>