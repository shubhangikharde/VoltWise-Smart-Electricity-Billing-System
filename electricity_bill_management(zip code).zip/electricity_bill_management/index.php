<!DOCTYPE html>
<html>
<head>
<title>Electricity Bill System</title>

<style>
body{
    font-family:Arial;
    background:linear-gradient(135deg,#1e3a8a,#0f172a);
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

.box{
    background:white;
    padding:40px;
    border-radius:15px;
    text-align:center;
    width:350px;
    box-shadow:0px 10px 25px rgba(0,0,0,0.3);
}

.btn{
    display:block;
    margin:10px 0;
    padding:12px;
    background:#1e3a8a;
    color:white;
    text-decoration:none;
    border-radius:8px;
}
</style>

</head>

<body>

<div class="box">

<h2>Electricity Bill Management</h2>

<a class="btn" href="admin_login.php">Admin Login</a>

<a class="btn" href="user_login.php">User Login</a>

</div>

</body>
</html>