<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "db.php";
include "header.php";
?>

<h2>Bill History</h2>

<table>
    <tr>
        <th>Bill ID</th>
        <th>Customer Name</th>
        <th>Meter Number</th>
        <th>Billing Month</th>
        <th>Units</th>
        <th>Rate (₹)</th>
        <th>Total Amount (₹)</th>
        <th>Bill Date</th>
        <th>Payment Status</th>
        <th>Action</th>
    </tr>

<?php

$query = "SELECT bills.bill_id,
                 bills.customer_id,
                 bills.meter_number,
                 bills.billing_month,
                 bills.units,
                 bills.rate,
                 bills.total_amount,
                 bills.bill_date,
                 bills.payment_status,
                 customers.customer_name
          FROM bills
          INNER JOIN customers
          ON bills.customer_id = customers.customer_id
          ORDER BY bills.bill_id DESC";

$result = mysqli_query($conn, $query);

if(!$result)
{
    die("SQL Error : ".mysqli_error($conn));
}

if(mysqli_num_rows($result) > 0)
{
    while($row = mysqli_fetch_assoc($result))
    {
?>

<tr>

<td><?php echo $row['bill_id']; ?></td>

<td><?php echo $row['customer_name']; ?></td>

<td><?php echo $row['meter_number']; ?></td>

<td><?php echo $row['billing_month']; ?></td>

<td><?php echo $row['units']; ?></td>

<td>₹ <?php echo $row['rate']; ?></td>

<td>₹ <?php echo $row['total_amount']; ?></td>

<td><?php echo $row['bill_date']; ?></td>

<td><?php echo $row['payment_status']; ?></td>

<td>
<a href="print_bill.php?id=<?php echo $row['bill_id']; ?>">
Print Bill
</a>
</td>

</tr>

<?php
    }
}
else
{
?>

<tr>
<td colspan="10">No Bill Records Found</td>
</tr>

<?php
}
?>

</table>

<?php
include "footer.php";
?>