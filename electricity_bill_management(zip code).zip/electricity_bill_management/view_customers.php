<?php
include "db.php";
include "header.php";
?>

<h2>Customer List</h2>

<table border="1" cellpadding="10" cellspacing="0" width="100%">
    <tr>
        <th>ID</th>
        <th>Customer Name</th>
        <th>Mobile</th>
        <th>Email</th>
        <th>Address</th>
        <th>Action</th>
    </tr>

<?php

$sql = "SELECT * FROM customers ORDER BY customer_id DESC";
$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0)
{
    while($row = mysqli_fetch_assoc($result))
    {
?>

<tr>
    <td><?php echo $row['customer_id']; ?></td>
    <td><?php echo $row['customer_name']; ?></td>
    <td><?php echo $row['mobile']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['address']; ?></td>

    <td>
        <a href="edit_customer.php?id=<?php echo $row['customer_id']; ?>">Edit</a> |
        <a href="delete_customer.php?id=<?php echo $row['customer_id']; ?>" onclick="return confirm('Are you sure you want to delete this customer?');">Delete</a>
    </td>
</tr>

<?php
    }
}
else
{
    echo "<tr><td colspan='6'>No Customers Found</td></tr>";
}
?>

</table>

<?php
include "footer.php";
?>