<?php
include "db.php";
include "header.php";

if(isset($_POST['save']))
{
    $name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $password = $_POST['password'];

    $sql = "INSERT INTO customers
            (customer_name, mobile, email, address, password)
            VALUES
            ('$name', '$mobile', '$email', '$address', '$password')";

    if(mysqli_query($conn, $sql))
    {
        echo "<script>
        alert('Customer Added Successfully');
        window.location='view_customers.php';
        </script>";
    }
    else
    {
        echo "<script>
        alert('Error : ".mysqli_error($conn)."');
        </script>";
    }
}
?>

<h2>Add Customer</h2>

<form method="POST">

<label>Customer Name</label>
<input type="text" name="customer_name" required>

<label>Mobile Number</label>
<input type="text" name="mobile" required>

<label>Email</label>
<input type="email" name="email">

<label>Address</label>
<textarea name="address" rows="4" required></textarea>

<label>Password</label>
<input type="password" name="password" required>

<button type="submit" name="save">
Save Customer
</button>

</form>

<?php
include "footer.php";
?>